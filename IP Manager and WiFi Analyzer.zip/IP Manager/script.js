document.addEventListener('DOMContentLoaded', function () {
    const trackButton = document.getElementById('trackButton');
    trackButton.addEventListener('click', updateMap);
});

function updateMap() {
    const latitudeInput = document.getElementById('latitudeInput').value;
    const longitudeInput = document.getElementById('longitudeInput').value;

    if (latitudeInput && longitudeInput) {
        const mapIframe = document.getElementById('map-frame');
        mapIframe.src = `https://www.google.com/maps/embed/v1/place?key=AIzaSyArBa8vyHFIwlMzpkJVAtot_Z0bn1Oidy8&zoom=11&q=${latitudeInput},${longitudeInput}`;
    }
}
