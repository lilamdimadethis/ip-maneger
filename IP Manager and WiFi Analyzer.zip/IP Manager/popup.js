// Function to update the device list in the popup
function updateDeviceList(devices) {
    // Clear the existing device list
    deviceList.innerHTML = '';

    // Add each device to the list
    devices.forEach(addDeviceToList);
}

document.addEventListener('DOMContentLoaded', function () {
    const developerModeButton = document.getElementById('developerMode');
    const exportDevicesButton = document.getElementById('exportDevices');
    const importDevicesButton = document.getElementById('importDevices');
    const fileInput = document.getElementById('fileInput');
    const deviceList = document.getElementById('deviceList');
    const addDeviceButton = document.getElementById('addDevice');
    const clearDevicesButton = document.getElementById('clearDevices');
    const errorMessage = document.getElementById('errorMessage');
    const goToPageButton = document.getElementById('goToPageButton');

    

    // Load devices from storage
    chrome.storage.sync.get('devices', function (data) {
        const devices = data.devices || [];
        updateDeviceList(devices);
    });

    
    // Load devices from backup file on popup.html reload
    // Assuming getBackupDevices is a method of an object called backupManager
    const backupManager = {
        getBackupDevices: function () {
            // Your implementation here
        }
    };

    // Calling the method
    backupManager.getBackupDevices();

    goToPageButton.addEventListener('click', function () {
        // Use chrome.tabs.update to redirect the current tab to page.html
        chrome.tabs.update({ url: 'page.html' });
    });

    const wifiAnalyzerButton = document.getElementById('wifiAnalyzerButton');
    wifiAnalyzerButton.addEventListener('click', function () {
        chrome.tabs.update({ url: 'page2.html' });
    });

    // Handle "Developer Mode" button click
    developerModeButton.addEventListener('click', function () {
        const isDeveloperMode = developerModeButton.classList.contains('developerModeEnabled');
        const confirmToggle = confirm(`Are you sure you want to ${isDeveloperMode ? 'disable' : 'enable'} developer mode?`);

        if (confirmToggle) {
            // Toggle developer mode
            developerModeButton.classList.toggle('developerModeEnabled');
            // Update visibility of import and export buttons
            updateImportExportVisibility();
        }
    });

    // Handle "Export Devices" button click
    exportDevicesButton.addEventListener('click', function () {
        exportDevices();
    });

    // Handle "Import Devices" button click
    importDevicesButton.addEventListener('click', function () {
        fileInput.click();
    });

    // Handle file input change (when a file is selected for import)
    fileInput.addEventListener('change', function (event) {
        importDevices(event);
    });

    // Handle "Add Device" button click
    addDeviceButton.addEventListener('click', function () {
        addDevice();
    });

    // Handle "Clear All Devices" button click
    clearDevicesButton.addEventListener('click', function () {
        clearAllDevices();
    });

    // Function to update visibility of import and export buttons
    function updateImportExportVisibility() {
        const isDeveloperMode = developerModeButton.classList.contains('developerModeEnabled');
        exportDevicesButton.style.display = isDeveloperMode ? 'block' : 'none';
        importDevicesButton.style.display = isDeveloperMode ? 'block' : 'none';
    }

    // Initial visibility setup
    updateImportExportVisibility();
});

function addDeviceToList(device) {
    const listItem = document.createElement('li');
    listItem.className = 'device-item';

    const deviceInfo = document.createElement('span');
    deviceInfo.innerHTML = `Name: ${device.name}, IP: ${device.ip}
        <button class="remove-button" data-device-name="${device.name}">Remove</button>`;

    // Add latitude and longitude to the deviceInfo
    if (device.details.latitude !== undefined && device.details.longitude !== undefined) {
        // Add Google Maps link as an image
        const mapLink = document.createElement('a');
        mapLink.href = `https://www.google.com/maps/place/${device.details.latitude},${device.details.longitude}`;
        mapLink.target = '_blank';

        // Create an image element for the link
        const mapImage = document.createElement('img');
        mapImage.src = 'https://creazilla-store.fra1.digitaloceanspaces.com/icons/3432298/map-icon-md.png'; // Replace with the actual path to your Google Maps icon
        mapImage.alt = 'View on Map';
        mapImage.style.width = '24px';
        mapImage.style.height = '24px';

        // Append the image element to the link
        mapLink.appendChild(mapImage);

        // Append the link to deviceInfo
        deviceInfo.appendChild(mapLink);
    }

    const table = document.createElement('table');
    table.className = 'country-info-table';

    // Extract country information using the provided tableData
    const tableData = [
        { key: 'IP', value: device.ip },
        { key: 'Hostname', value: device.details.hostname || "COULDN'T FIND" },
        { key: 'City', value: device.details.city || 'N/A' },
        { key: 'Region', value: device.details.region || 'N/A' },
        { key: 'Region Code', value: device.details.region_code || 'N/A' },
        { key: 'Country', value: device.details.country_name || 'N/A' },
        { key: 'Country Code', value: device.details.country_code || 'N/A' },
        { key: 'Postal Code', value: device.details.postal || 'N/A' },
        { key: "Latitude & Longitude", value: device.details.latitude && device.details.longitude ? `${device.details.latitude}, ${device.details.longitude}` : 'N/A' },
        { key: 'Timezone', value: device.details.timezone || 'N/A' },
        { key: 'UTC Offset', value: device.details.utc_offset || 'N/A' },
        { key: 'Currency', value: device.details.currency || 'N/A' },
        { key: 'Languages', value: device.details.languages || 'N/A' },
        { key: 'ASN', value: device.details.asn || 'N/A' },
        { key: 'Organization', value: device.details.org || 'N/A' },
        { key: 'Proxy', value: device.details.is_proxy ? 'Yes' : 'No' },
        { key: 'VPN', value: device.details.is_vpn ? 'Yes' : 'No' },
        { key: 'Mobile', value: device.details.is_mobile ? 'Yes' : 'No' },
        { key: 'Computer', value: device.details.is_mobile ? 'No' : 'Yes' },
        { key: 'Continent Code', value: device.details.continent_code || 'N/A' },
        { key: 'Capital', value: device.details.country_capital || 'N/A' },
        { key: 'Population', value: device.details.country_population || 'N/A' },
        { key: 'Area', value: device.details.country_area || 'N/A' },
        { key: 'Calling Code', value: device.details.country_calling_code || 'N/A' },
        { key: 'Internet TLD', value: device.details.country_tld || 'N/A' },
        { key: 'Carrier', value: device.details.org || 'N/A' },
        { key: 'Country in EU', value: device.details.in_eu ? 'Yes' : 'No' },
        { key: 'Country Code ISO3', value: device.details.country_code_iso3 || 'N/A' },
        { key: 'Country Name', value: device.details.country_name || 'N/A' },
        { key: 'Version', value: device.details.version || 'N/A' },
        { key: 'Currency Name', value: device.details.currency_name || 'N/A' },
        { key: 'Network', value: device.details.org || 'N/A' },
    ];

   // Populate the table with data
   tableData.forEach(item => {
    const row = document.createElement('tr');
    const keyCell = document.createElement('td');
    keyCell.textContent = item.key;
    const valueCell = document.createElement('td');
    valueCell.textContent = item.value;

    row.appendChild(keyCell);
    row.appendChild(valueCell);
    table.appendChild(row);
});

// Add an image element for the country flag
const countryFlag = document.createElement('img');
countryFlag.src = `https://static.abstractapi.com/country-flags/${device.details.country_code}_flag.png`;
countryFlag.alt = 'Country Flag';
countryFlag.className = 'country-flag';
countryFlag.style.width = '24px';
countryFlag.style.height = '24px';

// Append the image element to the deviceInfo span
deviceInfo.appendChild(countryFlag);

listItem.appendChild(deviceInfo);
listItem.appendChild(table);

// Initially hide the details
table.style.display = 'none';

deviceList.appendChild(listItem);

// Show details when clicking on the device
deviceInfo.addEventListener('click', function () {
    // Toggle the display of details
    table.style.display = table.style.display === 'none' ? 'block' : 'none';
});

// Handle remove button click
const removeButton = listItem.querySelector('.remove-button');
removeButton.addEventListener('click', function (event) {
    event.stopPropagation();
    const deviceName = removeButton.dataset.deviceName;

    // Remove the device from storage
    chrome.storage.sync.get('devices', function (data) {
        const devices = data.devices || [];
        const updatedDevices = devices.filter(device => device.name !== deviceName);

        chrome.storage.sync.set({ devices: updatedDevices }, function () {
            // Refresh the popup after removing the device
            updateDeviceList(updatedDevices);
        });
    });
});
}

function httpGetAsync(url, callback) {
const xmlHttp = new XMLHttpRequest();
xmlHttp.onreadystatechange = function () {
    if (xmlHttp.readyState === 4 && xmlHttp.status === 200) {
        callback(xmlHttp.responseText);
    }
};
xmlHttp.open("GET", url, true); // true for asynchronous
xmlHttp.send(null);
}

function showError(message) {
errorMessage.textContent = message;
}

function exportDevices() {
chrome.storage.sync.get('devices', function (data) {
    const devices = data.devices || [];

    // Convert devices to JSON string
    const jsonString = JSON.stringify(devices, null, 2);

    // Create a Blob and download it as a file
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'devices_export.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
});
}

function importDevices(event) {
const file = event.target.files[0];
if (file) {
    const reader = new FileReader();
    reader.onload = function (e) {
        try {
            const importedDevices = JSON.parse(e.target.result);

            // Update the devices in storage
            chrome.storage.sync.get('devices', function (data) {
                const existingDevices = data.devices || [];

                // Check and update devices based on IP
                importedDevices.forEach(importedDevice => {
                    const existingDeviceIndex = existingDevices.findIndex(device => device.ip === importedDevice.ip);

                    if (existingDeviceIndex !== -1) {
                        // Update details for existing device
                        existingDevices[existingDeviceIndex].details = importedDevice.details;
                    } else {
                        // Add new device
                        existingDevices.push(importedDevice);
                    }
                });

                chrome.storage.sync.set({ devices: existingDevices }, function () {
                    // Refresh the popup after importing devices
                    updateDeviceList(existingDevices);
                    // Hide error message
                    showError('');
                });
            });
        } catch (error) {
            // Show an alert with the error message
            alert('Error importing devices. Please make sure the file is in valid JSON format.');
        }
    };

    reader.readAsText(file);
}
}

function addDeviceToBackup(device) {
chrome.runtime.getBackgroundPage(function (backgroundPage) {
    backgroundPage.backupDevice(device);
});
}

// Check if backupDevice is created and initialized
if (typeof backupDevice !== 'undefined') {
// Access properties of backupDevice
// ...
} else {
console.error('backupDevice is undefined');
}

// Ensure backupDevice is created and initialized
const backupDevice = someFunctionThatCreatesBackupDevice();

function removeDeviceFromBackup(deviceName) {
chrome.runtime.getBackgroundPage(function (backgroundPage) {
    backgroundPage.removeDeviceFromBackup(deviceName);
});
}



function addDevice() {
let ip = prompt('Enter the IP of the new device:');
ip = ip.toLowerCase().trim() === 'my ip' ? '/' : ip;

let deviceName = prompt('Enter the name of the new device:');
if (deviceName === null) {
    return;
}
deviceName = deviceName.slice(0, 19);

httpGetAsync(`https://ipapi.co/${ip}/json/`, function (response) {
    try {
        const jsonResponse = JSON.parse(response);
        if (jsonResponse.error) {
            showError(jsonResponse.error.message);
        } else {
            chrome.storage.sync.get('devices', function (data) {
                const devices = data.devices || [];
                devices.push({ name: deviceName, ip: ip, details: jsonResponse });

                chrome.storage.sync.set({ devices: devices }, function () {
                    updateDeviceList(devices);
                    showError('');
                    addDeviceToBackup({ name: deviceName, ip: ip, details: jsonResponse });
                });
            });
        }
    } catch (error) {
        alert('An error occurred: ' + error.message);
    }
});
}

function removeDevice(deviceName) {
const confirmRemove = confirm(`Are you sure you want to remove the device '${deviceName}'?`);
if (confirmRemove) {
    chrome.storage.sync.get('devices', function (data) {
        const devices = data.devices || [];
        const updatedDevices = devices.filter(device => device.name !== deviceName);

        chrome.storage.sync.set({ devices: updatedDevices }, function () {
            updateDeviceList(updatedDevices);
            removeDeviceFromBackup(deviceName);
        });
    });
}
}

function isValidIP(ip) {
// Allow "my ip" as a valid input
if (ip.toLowerCase().trim() === 'my ip') {
    return true;
}

// Check if the entered IP is a valid IPv4 address
const ipv4Regex = /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/;
return ipv4Regex.test(ip);
}

function clearAllDevices() {
const confirmDelete = confirm("Are you sure you want to delete all devices? This cannot be undone.");
if (confirmDelete) {
    // Clear all devices from storage
    chrome.storage.sync.set({ devices: [] }, function () {
        // Refresh the popup after clearing devices
        updateDeviceList([]);
    });
}
}

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
if (request.action === 'disableDialog') {
    // Disable the confirmation dialog
    chrome.webNavigation.onBeforeNavigate.removeListener(disableConfirmationDialog);
}
});



function showError(message) {
console.log('Error: ' + message);
}