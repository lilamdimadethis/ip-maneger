// background.js

console.log('Background script loaded.');

// Add your background logic here

let backupDevices = [];

function backupDevice(device) {
    backupDevices.push(device);
    updateBackupFile();
}

function removeDeviceFromBackup(deviceName) {
    backupDevices = backupDevices.filter(device => device.name !== deviceName);
    updateBackupFile();
}

function updateBackupFile() {
    const jsonString = JSON.stringify(backupDevices, null, 2);

    chrome.runtime.getBackgroundPage(function (backgroundPage) {
        const blob = new Blob([jsonString], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'backup.txt';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    });
}

chrome.runtime.onInstalled.addListener(function () {
    // Load devices from backup file on extension startup
    chrome.storage.local.get('backupDevices', function (data) {
        backupDevices = data.backupDevices || [];
    });
});
