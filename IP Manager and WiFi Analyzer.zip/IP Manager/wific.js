document.addEventListener('DOMContentLoaded', function () {
    const ipInput = document.getElementById('ipInput');
    const validateButton = document.getElementById('validateButton');
    const validationResult = document.getElementById('validationResult');
    const connectionStatus = document.getElementById('connectionStatus');
    const connected = document.getElementById('connected');
    const consoleDiv = document.getElementById('console');
    const consoleContent = document.getElementById('consoleContent');
    const commandsDiv = document.getElementById('commands');
    const commandInput = document.getElementById('commandInput');
    const executeButton = document.getElementById('executeButton');

    validateButton.addEventListener('click', function () {
        const ip = ipInput.value.trim();
        if (validateIP(ip)) {
            validationResult.textContent = 'Valid IP';
            validationResult.style.color = 'green';
            connectionStatus.style.display = 'block';
            connected.textContent = `Connected to: ${ip}`;
            connected.style.backgroundColor = 'green';
            consoleDiv.style.display = 'block';
            commandsDiv.style.display = 'block';
            commandInput.focus();
            // Hide IP validation and Wi-Fi Analyzer title
            document.getElementById('ipValidation').style.display = 'none';
        } else {
            validationResult.textContent = 'Invalid IP';
            validationResult.style.color = 'red';
            connectionStatus.style.display = 'none';
            consoleDiv.style.display = 'none';
            commandsDiv.style.display = 'none';
            // Show IP validation
            document.getElementById('ipValidation').style.display = 'block';
        }
    });

    executeButton.addEventListener('click', function () {
        const command = commandInput.value.trim();
        if (command === 'clear') {
            consoleContent.innerHTML = '';
        } else if (command === 'exit') {
            connectionStatus.style.display = 'none';
            consoleDiv.style.display = 'none';
            commandsDiv.style.display = 'none';
            validationResult.textContent = 'Disconnected';
            validationResult.style.color = 'red';
            // Show IP validation
            document.getElementById('ipValidation').style.display = 'block';
        } else if (command.startsWith('rq')) {
            const [, ip, amount] = command.split(' ');
            const successMessage = `Packet send successful to ${ip}`;
            setTimeout(() => {
                consoleContent.innerHTML += `<div>${successMessage}</div>`;
            }, 2000);
            sendPacketsToIP(ip, amount);
        } else if (command === 'help') {
            consoleContent.innerHTML += `<div>Available commands: clear, exit, rq [IP] [amount]</div>`;
        } else {
            consoleContent.innerHTML += `<div class="invalid-command">Invalid command: ${command}. Type 'help' for a list of commands.</div>`;
        }
        commandInput.value = '';
    });

    commandInput.addEventListener('keypress', function (event) {
        if (event.key === 'Enter') {
            executeButton.click();
        }
    });
});

function validateIP(ip) {
    const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
    return ipRegex.test(ip);
}

function sendPacketsToIP(ip, amount) {
    // Simulate sending packets
    // Here you can place your actual code to send packets to the IP
    // For demonstration, let's assume it's successful if there's no error
    // If an error occurs, set `success` to false
    setTimeout(() => {
        console.log(`Packet send successful to ${ip}`);
    }, 2000);
}
