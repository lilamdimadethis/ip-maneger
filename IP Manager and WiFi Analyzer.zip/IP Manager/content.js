// content.js

// Function to send a message to the background script
function sendMessageToBackground(message, callback) {
    chrome.runtime.sendMessage(message, callback);
}

// Function to get all cookies on the current page
function getAllCookiesOnPage() {
    sendMessageToBackground({ action: 'getAllCookies' }, function (response) {
        if (chrome.runtime.lastError) {
            console.error('Error in sendMessageToBackground:', chrome.runtime.lastError);
            return;
        }

        console.log('Received response from background:', response);

        // Inform the popup about the cookies (if any)
        if (response && response.action === 'sendAllCookies' && Array.isArray(response.cookies)) {
            console.log('Cookies found:', response.cookies);
            chrome.runtime.sendMessage({ action: 'sendAllCookies', cookies: response.cookies });
        } else {
            console.error('Invalid response:', response);
        }
    });
}

// Execute the function to get cookies when the content script is injected
getAllCookiesOnPage();
